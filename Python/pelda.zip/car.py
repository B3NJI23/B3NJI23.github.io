class Car:
    def __init__(self, gyarto, modell, ferohely, toltes, tavolsag, gyartas_kezdet):
        self.gyarto = gyarto
        self.modell = modell
        self.ferohely = ferohely
        self.toltes = toltes
        self.tavolsag = tavolsag
        self.gyartas_kezdet = gyartas_kezdet
